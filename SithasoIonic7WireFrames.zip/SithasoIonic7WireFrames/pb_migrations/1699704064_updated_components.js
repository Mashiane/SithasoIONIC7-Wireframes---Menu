/// <reference path="../pb_data/types.d.ts" />
migrate((db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zgsu3t0mgv1znn5")

  collection.indexes = [
    "CREATE INDEX `idx_wPJBKcB` ON `components` (`_id`)"
  ]

  // add
  collection.schema.addField(new SchemaField({
    "system": false,
    "id": "qem7roig",
    "name": "_id",
    "type": "text",
    "required": false,
    "presentable": false,
    "unique": false,
    "options": {
      "min": null,
      "max": null,
      "pattern": ""
    }
  }))

  return dao.saveCollection(collection)
}, (db) => {
  const dao = new Dao(db)
  const collection = dao.findCollectionByNameOrId("zgsu3t0mgv1znn5")

  collection.indexes = []

  // remove
  collection.schema.removeField("qem7roig")

  return dao.saveCollection(collection)
})
